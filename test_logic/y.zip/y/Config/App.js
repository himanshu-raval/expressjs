module.exports = {
    "connectionString": "mongodb://localhost:27017/mean-angular2-registration-login-example",
    "apiUrl": "http://localhost:4000",
    "secret": "REPLACE THIS WITH YOUR OWN SECRET, IT CAN BE ANY STRING"
}