module.exports = {
    jokers:2,
    playerHandCards:5
}