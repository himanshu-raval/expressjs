import { Component, OnInit } from '@angular/core';


@Component({
	selector: 'pager',
	templateUrl: './pager.component.html',
	styleUrls: ['./pager.component.scss'],
})


export class PagerComponent implements OnInit {

	constructor() { }

    ngOnInit(){ }

}
