export const Config = {
       apiUrl: 'http://192.168.1.86:8000', // Himanshu PC 
      // apiUrl: 'http://192.168.2.37:8000', // Vinod PC 
     // apiUrl: 'http://35.165.51.160:8000'   // Live 
};
