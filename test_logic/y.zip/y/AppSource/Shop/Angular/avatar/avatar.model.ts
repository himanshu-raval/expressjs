export class Avatar {
    id: string;
    appId: string;
    username: string;
    email: string;
    phone: string;
    status: string;
    avatar: string;
}