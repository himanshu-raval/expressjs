export class Gems {
    id: string;
    appId: string;
    username: string;
    email: string;
    phone: string;
    status: string;
    gems: string;
}